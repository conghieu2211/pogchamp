﻿namespace NadekoBot.Core.Common
{
    public interface INadekoCommandOptions
    {
        void NormalizeOptions();
    }
}
