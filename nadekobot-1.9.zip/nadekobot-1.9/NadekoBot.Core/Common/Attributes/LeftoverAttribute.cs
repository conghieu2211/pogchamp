﻿namespace Discord.Commands
{
    public class LeftoverAttribute : RemainderAttribute
    {
        public LeftoverAttribute()
        {
        }
    }
}
