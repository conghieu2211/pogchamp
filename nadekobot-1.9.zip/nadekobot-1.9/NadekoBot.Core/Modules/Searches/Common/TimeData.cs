﻿using System;

namespace NadekoBot.Core.Modules.Searches.Common
{
    public class TimeData
    {
        public string Address { get; set; }
        public DateTime Time { get; set; }
        public string TimeZoneName { get; set; }
    }
}
