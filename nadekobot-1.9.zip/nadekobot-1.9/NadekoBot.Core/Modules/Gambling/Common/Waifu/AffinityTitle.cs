﻿namespace NadekoBot.Core.Modules.Gambling.Common.Waifu
{
    public enum AffinityTitle
    {
        Pure,
        Faithful,
        Defiled,
        Cheater,
        Tainted,
        Corrupted,
        Lewd,
        Sloot,
        Depraved,
        Harlot
    }
}
