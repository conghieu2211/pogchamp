﻿namespace NadekoBot.Core.Modules.Gambling.Common
{
    public class Payout
    {
        public string User { get; set; }
        public int Amount { get; set; }
    }
}
