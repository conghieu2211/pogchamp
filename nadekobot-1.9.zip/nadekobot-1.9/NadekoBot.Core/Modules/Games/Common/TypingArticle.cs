﻿namespace NadekoBot.Modules.Games.Common
{
    public class TypingArticle
    {
        public string Source { get; set; }
        public string Extra { get; set; }
        public string Text { get; set; }
    }
}
